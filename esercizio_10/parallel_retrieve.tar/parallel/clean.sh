rm avg_cost_*.dat
rm least_cost_*.dat
rm best_path_*.dat
rm glob_least_cost.dat
rm glob_best_path.dat
rm cities.dat
